import 'package:flutter/material.dart';

//para tabs
import 'screens/tab1.dart';
import 'screens/tab2.dart';
import 'screens/tab3.dart';
import 'screens/tab4.dart';

//para servicios
import 'services/options.dart';
import 'services/database.dart';

void main() {
  //se crea una instancia de la clase options
  Options(); //se inicializa el singleton options
  Db().dataBase; //se inicializa el singleton de la base de datos

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(home: MyHomePage());
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
        //para poner los tabs
        length: 4, //se especifica el numero de tabs
        child: Scaffold(
          appBar: AppBar(
            title: Text(
              "C.R.U.D. Example",
            ),
            centerTitle: true,
            bottom: TabBar(
              tabs: [
                //iconos para los tabs
                Tab(icon: Icon(Icons.create), child: Text('Create')),
                Tab(icon: Icon(Icons.read_more), child: Text('Read')),
                Tab(icon: Icon(Icons.update), child: Text('Update')),
                Tab(icon: Icon(Icons.delete), child: Text('Delete')),
              ],
            ),
          ),
          body: TabBarView(
            //vistas de los tabs
            children: [
              Tab1(),
              Tab2(),
              Tab3(),
              Tab4(),
              //Text('1'),
            ],
          ),
          floatingActionButton: FloatingActionButton(
            onPressed: () {
              Options().cleanPost(); //se limpia el post
              setState(() {});
            },
            tooltip: 'Increment',
            child: Icon(Icons.clear),
          ),
        ) // This trailing comma makes auto-formatting nicer for build methods.
        );
  }
}
