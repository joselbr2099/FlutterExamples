# sqlite
código de ejemplo de como usar una base de datos SQlite en Flutter
para agregar las dependencias:
	pub get (linux)
	flutter pub get  (windows)
	
para generar el diagrama de clases (https://pub.dev/packages/dcdg):
	dcdg -o diagrama.txt

se puede usar plantUML(https://plantuml.com/es/download) para visualizar el diagrama 
o usar la extension plantUML en Visual Studio Code
